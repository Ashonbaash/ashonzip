// this is my first time coding in js or in general
console.log('hello world')
